<?php

return [
    'db' => [
        'host' => 'localhost',
        'name' => 'swift_db',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4'
    ],
    'groq' => [
        'api_key' => 'YOUR_GROQ_API_KEY'
    ],
    'security' => [
        'dashboard_password' => 'admin'
    ]
];
